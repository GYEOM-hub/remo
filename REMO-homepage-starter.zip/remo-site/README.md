# REMO Website

REMO 팀 홈페이지 UI starter. Next.js App Router 기반이며 Vercel 배포를 전제로 합니다.

## Run
```bash
npm install
npm run dev
```

## Infrastructure target
- GitHub Repository: `REMO`
- Hosting: Vercel
- Domain: `REMO_com.leinnkorean.com`
- Database: Neon (Vercel)
- File storage: Vercel Blob
- Admin account: `remo_admin`

현재 버전은 UI/UX 프로토타입이며 프로젝트/학습/게시판/캘린더 데이터는 mock 데이터입니다. 다음 단계에서 Neon 인증 및 CRUD, Blob 업로드, 관리자 권한을 연결하면 됩니다.
