# REMO Site

## Neon 게시판 연동

게시판은 `/api/posts`를 통해 Neon PostgreSQL에 연결됩니다.

### 필요한 Vercel 환경변수

아래 둘 중 하나가 있으면 됩니다.

- `DATABASE_URL`
- `POSTGRES_URL`

Neon connection string을 그대로 Vercel Project Settings → Environment Variables에 등록하세요.

### 배포

1. GitHub 저장소에 이 프로젝트의 변경사항을 push합니다.
2. Vercel이 해당 저장소를 배포합니다.
3. Vercel 환경변수에 `DATABASE_URL` 또는 `POSTGRES_URL`이 있는지 확인합니다.
4. 배포 후 홈페이지의 `커뮤니티 → 글쓰기 +`에서 테스트 게시글을 작성합니다.
5. 작성 직후 목록에 표시되고, 새로고침 후에도 표시되면 DB 연동이 정상입니다.

### DB 테이블

`schema.sql`에 `posts` 테이블 정의가 있습니다. API도 최초 접근 시 `CREATE TABLE IF NOT EXISTS posts`를 실행하므로 별도 SQL 실행 없이 시작할 수 있습니다. Neon 계정의 DB 사용자에게 테이블 생성 권한이 없는 경우에는 Neon SQL Editor에서 `schema.sql`을 한 번 실행하세요.

### 로컬 실행

```bash
npm install
npm run dev
```

`.env.local` 예시:

```env
DATABASE_URL=postgresql://USER:PASSWORD@HOST/DATABASE?sslmode=require
```
